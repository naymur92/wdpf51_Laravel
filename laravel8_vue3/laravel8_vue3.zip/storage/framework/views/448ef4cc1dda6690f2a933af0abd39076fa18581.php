<?php $__env->startSection('content'); ?>
  <front-template></front-template>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/wdpf51_Laravel/laravel8_vue3/resources/views/front.blade.php ENDPATH**/ ?>