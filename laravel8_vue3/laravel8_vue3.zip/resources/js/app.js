require("./bootstrap");

import { createApp } from "vue";
import FrontTemplate from "./FrontTemplate.vue";

const app = createApp({});

app.component("front-template", FrontTemplate);

app.mount("#app");
